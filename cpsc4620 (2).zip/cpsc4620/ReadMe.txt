Name: Ethan Coffey
Partner: Taylor Boyles

Basic Info on This Project

My Partner and I both worked on the database and java code together.

- DBConnector, DBNinja are the two files that were modified for this project 
(the rest of the file were given to us and didn't need to be updated)

DBConnector: Deals with connecting to the Pizzeria Database in MySQL

DBNinja: Deal with adding and retriving data from the Database

Last thing to note, you can look at everything related to this code, however it won't run correctly 
(due to the database being out of commision, we used AWS for our database, however it was only used for the class so it closed when the course finished).
If you were to load this code into AWS Simply run DBNinja (considered the main of the file) you will get basic functionality.