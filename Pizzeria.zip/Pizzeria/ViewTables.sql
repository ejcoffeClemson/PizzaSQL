USE PIZZERIA;
SELECT * FROM discount;
SELECT * FROM customer;
SELECT * FROM topping;
SELECT * FROM baseprice;
SELECT * FROM `order`;
SELECT * FROM orderdiscount;
SELECT * FROM pizza;
SELECT * FROM pizzadiscount;
SELECT * FROM bridgetopping;
SELECT * FROM delivery;
SELECT * FROM dinein;
SELECT * FROM pickup;
-- Used to view all tables in a populated database
-- SELECT Order_ID,OrderCustomer,OrderType,OrderStatus FROM `order` WHERE OrderTimeStamp >= '2024-3-25';
-- SELECT OrderTimeStamp FROM `order`;